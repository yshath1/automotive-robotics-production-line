"""Minimal deterministic three-station automotive assembly line demonstration.

Educational simulation: not a physical ABB RobotStudio or Simulink integration.
"""
from __future__ import annotations

import argparse
import csv
import json
from dataclasses import dataclass
from pathlib import Path
from xml.sax.saxutils import escape


@dataclass(frozen=True)
class Station:
    name: str
    seconds_per_car: int


DEFAULT_STATIONS = (
    Station("Body handling", 5),
    Station("Welding", 8),
    Station("Inspection", 4),
)


def simulate(cars: int, stations=DEFAULT_STATIONS):
    """Return event rows and aggregate summary for a fixed-order production line.

    Cars are admitted to the first station as quickly as it becomes free.
    Downstream stations may queue between processes (unbounded buffers).
    """
    if cars < 1:
        raise ValueError("cars must be at least 1")
    if not stations or any(s.seconds_per_car <= 0 for s in stations):
        raise ValueError("stations must be nonempty with positive durations")
    station_ready = [0] * len(stations)
    events = []
    completion_times = []
    first_starts = []
    for car_id in range(1, cars + 1):
        ready_from_previous = 0
        for index, station in enumerate(stations):
            start = max(station_ready[index], ready_from_previous)
            end = start + station.seconds_per_car
            events.append({"car": car_id, "station": station.name,
                           "start_s": start, "end_s": end,
                           "duration_s": station.seconds_per_car})
            station_ready[index] = end
            ready_from_previous = end
            if index == 0:
                first_starts.append(start)
        completion_times.append(ready_from_previous)
    elapsed = completion_times[-1]
    summary = {
        "simulation_type": "synthetic demonstration (not physical hardware)",
        "cars_completed": cars,
        "total_elapsed_s": elapsed,
        "average_flow_time_s": round(sum(e-s for e, s in zip(completion_times, first_starts)) / cars, 2),
        "throughput_cars_per_hour": round(cars * 3600 / elapsed, 2),
        "stations": [
            {"name": s.name, "processing_time_s": s.seconds_per_car,
             "busy_time_s": s.seconds_per_car * cars,
             "utilization_percent": round(s.seconds_per_car * cars / elapsed * 100, 2)}
            for s in stations
        ],
    }
    return events, summary


def make_timeline_svg(events, stations=DEFAULT_STATIONS):
    """Produce a self-contained SVG Gantt timeline with no third-party packages."""
    total = max(event["end_s"] for event in events)
    scale = min(12.0, 920 / max(1, total))
    w, left, row_h, top = 1080, 160, 58, 65
    h = top + len(stations) * row_h + 60
    colors = ["#2563eb", "#0891b2", "#7c3aed", "#ea580c"]
    lines = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">',
             '<rect width="100%" height="100%" fill="#ffffff"/>',
             '<text x="22" y="30" font-size="19" font-family="Arial" fill="#0f172a">Automotive line — illustrative simulation timeline</text>',
             '<text x="22" y="49" font-size="12" font-family="Arial" fill="#475569">Synthetic durations; not RobotStudio or hardware measurements</text>']
    for i, s in enumerate(stations):
        y = top + i * row_h
        lines.append(f'<text x="18" y="{y+22}" font-size="13" font-family="Arial" fill="#334155">{escape(s.name)}</text>')
        lines.append(f'<line x1="{left}" y1="{y+30}" x2="{left+total*scale:.1f}" y2="{y+30}" stroke="#cbd5e1"/>')
        for event in events:
            if event['station'] == s.name:
                x=left+event['start_s']*scale
                width=max(1.5,event['duration_s']*scale-1)
                lines.append(f'<rect x="{x:.1f}" y="{y+6}" width="{width:.1f}" height="22" rx="2" fill="{colors[i%len(colors)]}"/>')
    lines.append(f'<text x="{left}" y="{h-20}" font-size="12" font-family="Arial" fill="#475569">Time: 0 to {total} seconds →</text>')
    lines.append('</svg>')
    return '\n'.join(lines)


def write_outputs(events, summary, directory: Path):
    directory.mkdir(parents=True, exist_ok=True)
    with (directory / 'events.csv').open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=['car','station','start_s','end_s','duration_s'])
        writer.writeheader()
        writer.writerows(events)
    (directory / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
    (directory / 'timeline.svg').write_text(make_timeline_svg(events), encoding='utf-8')


def main():
    parser = argparse.ArgumentParser(description='Automotive factory line illustration (simulation only)')
    parser.add_argument('--cars', type=int, default=10, help='Number of cars, must be positive')
    parser.add_argument('--output', type=Path, default=Path('output'))
    args = parser.parse_args()
    events, summary = simulate(args.cars)
    write_outputs(events, summary, args.output)
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
