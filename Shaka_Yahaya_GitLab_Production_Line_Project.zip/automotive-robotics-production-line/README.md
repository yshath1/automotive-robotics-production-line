# Automotive production-line automation — Python simulation

**Author:** Shaka Yahaya  
**Application context:** Junior Robotics Engineer, Cota Robotics (Stockholm)  
**Type:** Reconstructed educational demonstration, **simulation only**.

## Why this repository exists

This small, original Python project provides a reproducible example of ideas relevant to my reported automotive factory automation simulation using **ABB RobotStudio and MATLAB/Simulink**. It is **not** an export of that earlier project and does **not** include RobotStudio station files, Simulink `.slx` models, ABB RAPID programs, or evidence of deploying code to a physical robot. The original simulation artifacts were not available when this repository was prepared. The model, code and scenario here are newly created for portfolio illustration, not claimed as coursework deliverables or measured factory data.

## What it models

A simplified automotive assembly line with three sequential stations:

1. **Body handling:** an industrial robot moves a body component into position.
2. **Welding:** a second station processes the positioned body.
3. **Inspection:** a quality-check station completes the cycle.

Each station has a processing time, a one-part-at-a-time capacity, and a queue. The scheduler tracks work in process, completed vehicles, and cycle times. Durations are **illustrative assumptions**, not measurements from ABB robots or a real car factory.

## Quick start (Python 3.10+, no dependencies)

```bash
python -m src.production_line --cars 10 --output output
python -m unittest discover -s tests -v
```

The simulation writes `output/events.csv`, `output/summary.json`, and `output/timeline.svg` (a simple station utilization timeline). The repository includes **example output** generated from the default run, which can be regenerated with the first command.

## Example output (10 cars; synthetic timings)

Default per-station cycle times: body handling **5 s**, welding **8 s**, inspection **4 s**. These are illustrative and should not be presented as actual ABB performance data. For a 10-car batch, the deterministic simulation reports the time to finish all cars, average time from start to finish and station busy durations.

## How it relates to RobotStudio / Simulink

- **ABB RobotStudio** could be used to build cell layouts, validate reachability, program virtual ABB robots, and coordinate station events.
- **MATLAB/Simulink** could model control states, discrete-event logic, and supervisory automation.
- This repository uses a standalone, simplified **Python queue-and-event model** only. It does **not** connect to RobotStudio, implement an actual PLC, or execute RAPID.

An example integration plan is in [`docs/robotstudio_simulink_mapping.md`](docs/robotstudio_simulink_mapping.md).

## Repository organization

```text
src/production_line.py            Deterministic production-line simulation
src/__init__.py                 Python package marker
tests/test_production_line.py    Automated unit tests
docs/robotstudio_simulink_mapping.md   Conceptual integration mapping
docs/evidence_and_limitations.md      Evidence guide and candid limitations
output/                         Reproducible example outputs
.gitlab-ci.yml                  GitLab CI smoke test
LICENSE                         MIT license
```

## Next steps with the real project

If the original RobotStudio station files, Simulink models, screenshots, reports, or video are available, add them **only after confirming ownership/permission** and explain exactly what was done in them. If you have a separate project deployed to real hardware, link that separately—this repository does not satisfy a physical-hardware demonstration requirement.

## License

MIT. See [LICENSE](LICENSE).


## Related Allen-Bradley PLC simulation experience (applicant-reported)

Shaka Yahaya has separately reported **simulation-only** experience with Allen-Bradley PLCs, covering:

- Ladder Logic programming
- HMI/SCADA
- Industrial robot integration
- Sensors and actuators

The particular PLC model, programming environment, I/O mapping, routines, simulator, and test outcomes have **not** been supplied. This repository's Python production-line simulation is **not** an Allen-Bradley PLC project, and no PLC binaries, Ladder Logic files, HMI screens, or real-hardware deployment are claimed. The ABB RobotStudio/Simulink automotive project is also described as simulation-only.

To document authentic PLC work, add your own exported ladder diagrams, HMI screenshots, controller configuration, I/O list, and explanation in `docs/` once available; label each artifact with its actual source.

## RSLogix 500 technical report case study (review dated 20 November 2026)

See [`docs/rslogix500_report_case_study.md`](docs/rslogix500_report_case_study.md). This reviews a separately supplied 30-page historical RSLogix 500/MicroLogix 1400 report printed **16 November 2013**. Its printed date is not changed. The case study is a **2026 analysis**, not a claim to have authored the original program or run it on hardware. The original PDF is excluded pending confirmation of sharing rights.
