import tempfile
import unittest
from pathlib import Path
from src.production_line import Station, simulate, write_outputs


class ProductionLineTests(unittest.TestCase):
    def test_single_car_completion(self):
        events, summary = simulate(1)
        self.assertEqual(summary['cars_completed'], 1)
        self.assertEqual(summary['total_elapsed_s'], 17)
        self.assertEqual([(e['start_s'], e['end_s']) for e in events], [(0, 5), (5, 13), (13, 17)])

    def test_ten_cars_expected_bottleneck(self):
        events, summary = simulate(10)
        self.assertEqual(len(events), 30)
        self.assertEqual(summary['total_elapsed_s'], 89)
        self.assertEqual(summary['stations'][1]['busy_time_s'], 80)
        self.assertEqual(summary['cars_completed'], 10)

    def test_each_car_follows_station_order(self):
        events, _ = simulate(7)
        for car_id in range(1, 8):
            stages = [e for e in events if e['car'] == car_id]
            for previous, next_stage in zip(stages, stages[1:]):
                self.assertGreaterEqual(next_stage['start_s'], previous['end_s'])

    def test_no_overlapping_jobs_per_station(self):
        events, _ = simulate(10)
        for station in {e['station'] for e in events}:
            sorted_events = sorted((e for e in events if e['station'] == station), key=lambda e: e['start_s'])
            self.assertTrue(all(b['start_s'] >= a['end_s'] for a, b in zip(sorted_events, sorted_events[1:])))

    def test_reject_invalid_inputs(self):
        with self.assertRaises(ValueError):
            simulate(0)
        with self.assertRaises(ValueError):
            simulate(1, [Station('Broken', 0)])

    def test_output_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            events, summary = simulate(2)
            write_outputs(events, summary, Path(tmp))
            for name in ('events.csv', 'summary.json', 'timeline.svg'):
                self.assertTrue((Path(tmp) / name).exists())


if __name__ == '__main__':
    unittest.main()
