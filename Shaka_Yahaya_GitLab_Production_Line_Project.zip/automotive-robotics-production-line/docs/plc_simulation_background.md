# Allen-Bradley PLC simulation background

**Source:** Applicant-provided description; not independently verified by project artifacts.

**Platform:** Allen-Bradley PLC (exact model and software not provided).

**Activities reported:** Ladder Logic programming; HMI/SCADA; industrial robot integration; sensors and actuators.

**Hardware status:** Simulation only. No physical PLC deployment claimed.

**Relationship to this repository:** This repository provides a separate original Python factory-line simulation. It does not implement an Allen-Bradley PLC, a Ladder Logic runtime, or HMI/SCADA. The relationship of the applicant's PLC simulation to their ABB RobotStudio/Simulink project has not been specified.

## Evidence to add from original work (if available)

1. PLC programming environment and simulator name/version.
2. Exported Ladder Logic files or screenshots of routines.
3. HMI/SCADA screenshots and descriptions.
4. I/O list, sensors/actuators, and simulated robot communication details.
5. Simulation results or test screenshots.

Never upload confidential employer or school materials without permission.
