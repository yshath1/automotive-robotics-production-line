# Evidence, authorship, and limitations

## What can be substantiated by this repository

- A **newly authored** runnable Python scheduling simulation with self-contained source code.
- Deterministic example outputs, automatically generated SVG timeline and automated tests.
- Documentation of how a production-line simulation might map to RobotStudio and Simulink.

## What this repository does not establish

- That the Python implementation is the actual code used in Shaka Yahaya's earlier ABB RobotStudio/Simulink project.
- That any physical ABB robot, PLC, Arduino, Raspberry Pi or other hardware was operated.
- That RobotStudio, Simulink, or RAPID models are included or integrated.
- That simulated station durations represent performance of actual manufacturing equipment.
- That Cota Robotics' specific hardware-evidence requirement is met.

## How to improve the portfolio evidence

If available, upload **authentic** screenshots or a video of the ABB RobotStudio station and relevant Simulink models, together with the original files you own or have permission to share. Provide your specific role, tasks and results. For real hardware experience, document a separate actual build and testing process.

## Suggested accurate one-line description

> A small Python production-line simulation created as a portfolio companion to my ABB RobotStudio/Simulink automotive factory automation project; it models sequential robot stations and reports synthetic throughput metrics.
