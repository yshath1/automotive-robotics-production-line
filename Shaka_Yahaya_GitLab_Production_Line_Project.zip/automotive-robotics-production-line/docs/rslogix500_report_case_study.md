# RSLogix 500 / MicroLogix 1400 — technical report review

**Analysis prepared:** 20 November 2026  
**Reference report:** `DEMOTEST.RSS` (PDF printout originally dated **16 November 2013**)  
**Evidence status:** Document analysis of a user-supplied reference; **not** original ladder source files, a PLC simulation run, evidence of authorship, or proof of deployment to hardware.

## Controller and architecture in the report

The report identifies an **Allen-Bradley MicroLogix 1400 Series A** (Bulletin 1766), a **1762-IF2OF2** analog I/O expansion and **1762-IT4** thermocouple inputs (PDF pp. 2–3). Its ladder-program list (p. 5) contains `MAIN`, `D INPUT`, `D OUTPUT`, `A INPUT`, `A OUTPUT`, `CONTROLS`, `ALARMS`, and `DISPLAY`.

## Observations from the supplied report

| Section in report | Observable logic | PDF pages |
|---|---|---|
| Digital I/O | Pushbuttons, pressure/flow/level switch mapping; blower, pump, valve, heater relay and alarm horn outputs | 9–10 |
| Analog I/O | SCP scaling for tank level and temperature; range checks and heater signal output | 11–13 |
| Operator/HMI interface | OFF/ON/FAULTED system mode, HMI start/stop, blower HAND/OFF/AUTO commands | 14–16 |
| Sequencing | Delayed level-triggered tank filling, one-shot logic and pump latch conditions | 17–19 |
| PID | Temperature setpoint, process variable and heater control variable | 20 |
| Alarms | Delayed tank-level alarm and retained operator notifications | 21 onward |

## Interpretation

The historical program is a study example of modular ladder control logic, with I/O mapping separated from process control and alarms. The new analysis explains the structure; it does not establish that the applicant wrote, tested, or deployed the original program.

## Relationship to other portfolio items

This case study is **separate** from the applicant-reported ABB RobotStudio/MATLAB Simulink car-factory simulation and from the newly authored Python automotive-line demonstration in this repository. No PLC runtime, .RSS source, or physical hardware proof is included.

## Before publishing more evidence

If you have the original `DEMOTEST.RSS` editable file, your own screenshots or HMI files, confirm your contribution and sharing rights before uploading. **The original PDF is not packaged in this repository**, because copyright/permission have not been established.
